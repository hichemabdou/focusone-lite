import ClassicClient from "./ClassicClient";

export default function ClassicPage() {
  return (
    <main className="min-h-screen bg-neutral-950 text-neutral-100">
      <ClassicClient />
    </main>
  );
}
